## practice with pandas (from doc)
import os
def cls():
    os.system("cls")


import numpy as np
import pandas as pd
import csv
# series
s = pd.Series([1, 2, 3, np.nan, 5, 6])
s

# dataframes
dates = pd.date_range("2017-01-01", freq = "M", periods = 6)
# "Q" for "quarterly", "M" for "monthly", etc.
# supports multiple arguments
df1 = pd.DataFrame(s, dates)
inspect.signature(pd.DataFrame) # like str() in R

df2 = pd.DataFrame(np.random.normal(0, 1, (6, 6)),
    index = dates,
    columns = list("ABCDEF")) # columns and index argument required
# create dataframe from a dictionary
dict1 = {"A" : [1, 2, 3], "B" : ["one", "two", "three"]}
dict1
# it's also possible to convert a list of dictionaries to DataFrame
with open(r"C:\Users\ludann\Desktop\Python_shit\Datasets\quarterly_data.csv") as csvfile:
    IFRS9data = list(csv.DictReader(csvfile))

bigdata = pd.DataFrame(IFRS9data)

# viewing data
bigdata.head()
bigdata.tail()
bigdata.index #get or set column names
bigdata.columns #get or set column names
#subsetting by names
bigdata["GROSS_EXPOSURE"] # or
bigdata.GROSS_EXPOSURE
#returns a series
bigdata[["GROSS_EXPOSURE", "IFRS9_PROV"]]
# returns a data frame
# sorting data
bigdata.sort_index(axis=1, ascending = False)
# axis = 1 is columns, axis = 0 is rows
bigdata.sort_values(by = "GROSS_EXPOSURE")
#slicing
bigdata[0:3] #slices rows (works only with slices)
# selection by label useful if the index is not just [0, 1, ...]
df2.loc["2017-03-31"]
df3 = pd.DataFrame({"A" : np.random.normal(0, 1, 6),
    "B" : np.random.binomial(1, 0.7, 6)})
df3.index = pd.date_range("20180101", periods = 6, freq = "M")

df3.loc["2018-01-01":"2018-01-31"]
#both ends of the range are included in the selection
df3.loc["2018-01-01":"2018-01-31", "B"]
df3.loc["2018-01-01":"2018-01-31", "A":"B"]
df3.loc["2018-03-01", "A"]
df3.at[2018-03-01, "A"] # searches by column and row name
# doesn't work because the index is a timestamp not a string
# selecting by position
bigdata.iloc[0:3, 0:2]
bigdata.iloc[[1, 2, 5], [1, 6, 7]]
bigdata.iloc[0, 0] #returns just the value (not as dataframe)
#boolean indexing
bigdata[bigdata.QUARTER == "2018-06-30"]
bigdata[QUARTER == "2018-06-30"]

bigdata[bigdata > 3000].GROSS_EXPOSURE ## works only for all-numeric arrays

bigdata["STAGE"].isin(["Stage 3"])
# returns a series of logicals
# the argument to isin() must be a list
bigdata[bigdata.SEGMENT.isin(["Corporate", "SME Retail"])]

bigdata[bigdata.SEGMENT.isin(["Corporate", "SME Retail"])].

# selecting all columns except one
bigdata = bigdata.iloc[:, bigdata.columns != "BANK"] #or
truncated = bigdata.drop("BANK", axis = 1)

#adding a column
banks = bigdata.BANK
banks.index = np.random.choice(range(0, len(banks), len(banks), False))
truncated["BANK"] = banks #joins by row index

# reindexing (doesn't alter the original data)
bigdata.reindex(index = range(300, 310),
    columns = ["BANK", "QUARTER", "GROSS_EXPOSURE"])
# returns all row that match the index
bigdata.reindex(index = ["a", "b", "c"],
    columns = ["BANK", "QUARTER", "GROSS_EXPOSURE"])

# missing data
df3 = pd.DataFrame(np.array([1, 2, 3, np.nan, 5, np.nan, 7, 8, np.nan]).reshape(3, 3))
# issue with non-numerical missing dataframe

df3.dropna(0) #drops all rows containing NaNs
df3.dropna(1) #drops all columns containing NaNs
df3.fillna("EBET") # fills NaNs with specified arguments
df3.isna() #returns dataframe of s

# exercise: changing a column's class
for i in range(0, len(bigdata)):
    bigdata.GROSS_EXPOSURE[i] = int(bigdata.GROSS_EXPOSURE[i])
    bigdata.IFRS9_PROV[i] = float(bigdata.IFRS9_PROV[i])

#basic operations
bigdata.mean() #weird, doesn't work for bigdata
# drops non numeric columns
df3
df3["C"] = np.random.choice(range(0, len(df3)), len(df3))
df3.mean()

bigdata.sum()

# shifts data one row down, producing NaNs in the now empty first row
df3.shift(1)
# shifts time index up (run for an example)
df3.shift(1, freq = "M")

#generate some fake numerical dataframe
#indeces
dates = pd.date_range("2017-01-01", freq = "M", periods = 50)
#data
errors_rw = np.random.normal(0, 2, 50)
rw1 = np.array([])
x = 0
for i in range(0, 50):
    x += errors_rw[i]
    rw1 = np.hstack([rw1, x])

# generate an AR1
errors_ar = np.random.normal(0, 1, 50)
ar1 = np.array([])
y = 0
for i in range(0, 50):
    y = 0.5*y + errors_ar[i]
    ar1 = np.hstack([ar1, y])

Dict1 = {"AR1" : ar1, "RW" : rw1,
    "E_AR1" : errors_ar, "E_RW" : errors_rw}
TS = pd.DataFrame(index = dates, data = Dict1)

np.cumsum(TS.E_RW)[49] == TS.RW[49]

# apply
TS.apply(sum, axis = 0)
TS.min()
TS.std()
# merge

pieces = [TS[:4], TS[4:30], TS[30:49]]
pd.concat(pieces) #vertical binding
# if columns don't match, then additional columns are added
# and filled with NaNs
#analogous
pieces[0].append(pieces[1]).append(pieces[2])
pd.concat(pieces, axis = 1) #horizontal binding


# joining
pieces2 = [bigdata.drop("GROSS_EXPOSURE", axis = 1),
    bigdata.drop("IFRS9_PROV", axis = 1)]
pd.merge(pieces2[0], pieces2[1], on = ["PRODUCT_TYPE"])
# if rows don't match, then they are added to the df
pd.merge(pieces2[0], pieces2[1],
    on = ["PRODUCT_TYPE", "SEGMENT", "BOND_TYPE", "STAGE", "BANK", "QUARTER"])

#groupby
bigdata.groupby("STAGE")[["GROSS_EXPOSURE", "IFRS9_PROV"]].sum()
bigdata.groupby(["STAGE", "PRODUCT_TYPE"])[["GROSS_EXPOSURE", "IFRS9_PROV"]].sum()
## I can groupby functions of variables
#reshaping
pd.DataFrame(np.random.normal(0, 1, (4, 4)), columns = list("ABCD"))
bigdata.stack()
#compresses one level in the dataframe's columns
# multiindexing
tuples = list(zip(*[("one", "one", "two", "two"),
    ("Good", "Bad", "Good", "Bad")]))
index = pd.MultiIndex.from_tuples(tuples, names = ("one", "two"))

test = pd.DataFrame(np.random.randint(0, 10, (4, 4)), index = index,
    columns = list("ABCD")).T #multiple column levels

test.stack("one") #collapses one levels
test.stack(["one", "two"]) # collapses both levels
test.unstack(["one", "two"])


# if there is only one level stack() converts the dataframe to a two-index
# Series

df3
pd.pivot_table(df3, values = "A", columns = "B")
pd.pivot_table(df3, values = "A", index = "B")
# computes mean by default (?)
test = bigdata[bigdata.SEGMENT != "Intra-group Exposures"]
test["NEWCOL"] = pd.Series((1, 2, 3)*int(len(test)/3), index = test.index)

pd.pivot_table(test, values = "NEWCOL",
    index = "BANK", columns = "STAGE")

pd.pivot_table(test, values = "GROSS_EXPOSURE",
    index = "BANK", columns = "STAGE")
# doesn't seem to work with this data (fuck knows why)
# multiindexed pivot_table
pd.pivot_table(test, values = "GROSS_EXPOSURE",
    index = ["BANK", "STAGE"])
#time Series
rng = pd.date_range("20180101", periods = 100, freq = "D")
ts = pd.Series(np.random.randint(0, 500, len(rng)), index = rng)
ts.resample("15D").sum() #aggregates by 15 days
ts.resample("12H").sum() # also works the other way around but
# assigns value zero to intermediate values
ts_utc = ts.tz_localize("UTC")
ts_utc.tz_convert("US/Eastern")
ps = ts.to_period("M")
ps.to_timestamp()
# exercise
bigdata["EXPOSURE_NUM"] = bigdata.GROSS_EXPOSURE.astype("float")
bigdata["PROVISION_NUM"] = bigdata.IFRS9_PROV.astype("float")

def bankquarter(bank, quarter):
    df1 = bigdata[bigdata.BANK == bank][bigdata.QUARTER == quarter]
    return [[pd.pivot_table(df1[df1.PRODUCT_TYPE == i],
        values = j, index = "SEGMENT",
        columns = "STAGE", margins = True, margins_name = "TOTAL")
        for i in ["Loans", "Bonds"]]
        for j in ["EXPOSURE_NUM", "PROVISION_NUM"]]

bankquarter("CIB", "2018-03-31")[0]

#categoricals
bigdata.STAGE = bigdata.STAGE.astype("category")
bigdata.STAGE.cat.categories #show categories
bigdata.STAGE.cat.set_categories("Indevas", "Gnurant", "Zagnuc")

# reading and writing CSV files
bigdata2 = pd.read_csv("quarterly_data.csv")
bigdata2.dtypes
bigdata2 = pd.read_csv("quarterly_data.csv", dtype = [str, str, str, str, float, float, str, str])


## cookbook
#idioms
df = pd.DataFrame({"A": np.random.normal(0, 1, 100),
    "B": np.random.binomial(3, 0.5, 100),
    "C": ["a", "b", "c", "d"]*25})
# if-then
df.loc[df.A > 0, "B"] = 1; df #alters data
df.loc[df.A > 0, "A"] = 2;df #useful to cap values
#add new column
df.loc[df.A > 0, "D"] = 0
df.loc[df.A <= 0, "D"] = 1
# unclear
df.loc[(df.A > 0) & (df.B == 0), "E"] = "sega"
s1 = df.B == 0
#if-then using "where"
df.A.where(df.B == 1, 0)
df.A.where(df.B == 1, 0, inplace = True)
# create bins
df.A.where(abs(df.A) < 0.68, 1)
df["F"] = np.where(df.A >= 0, "high", "low")
df[df.A > 0]
## multi-column criteria
df.loc[(df.C == "b") & (df.B == 1), "G"] = "fuck"
# fills rows for which conditions isn't met with NaNs
df["G"] = np.where((df.C == "b") & (df.B == 1), "no", "yes")
# create logical using list comprehension
bo1 = [i in ["Stage 1", "Stage 2"] for i in IFRS9.STAGE]
IFRS9["Flag_performing"] = np.where(bo1, "performing", "non-performing")

## selection
GHG_notext = pd.read_csv(r"C:\Users\ludann\Desktop\Python_shit" +
    r"\Datasets\emssions_data.csv")

(GHG_notext[(GHG_notext.MS == "IT") &
    (GHG_notext.Category_name.
        isin(["Agriculture", "Energy industries"]))].
    sort_values(by = "Reported Value", ascending = False))

(GHG_notext[~((GHG_notext.MS == "IT") &
    (GHG_notext.Category_name.
        isin(["Agriculture", "Energy industries"])))].
    sort_values(by = "Reported Value", ascending = False))
# tilde gets the complementary of a boolean mask
## multiindexing

GHG_hier = (GHG_notext.set_index(["MS", "Category_name"], append = True).
reorder_levels(["MS", "Category_name", "index"]))

GHG_hier.loc["IT", "Agriculture"]
GHG_hier.loc[["IT", "AT"], ["Agriculture", "Other sectors"], :] # be sure to specify the column

GHG_notext.notnull() # returns a boolean for each dataframe element
