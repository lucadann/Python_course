'''
Functional programming uses immutable data structures. They should be the core part of the program

'''
import collections

LOTR_character = collections.namedtuple('LOTR_character', ['name', 'race', 'hero', 'survives', 'weapons'])

gandalf = LOTR_character('Gandalf', 'Wizard', True, True, ['Sword', 'Staff'])

print(gandalf)
print(gandalf.name)
## I can't modify attributes in a named tuple instance
aragorn = LOTR_character('Aragorn', 'Man', True, True, 'Sword')
legolas = LOTR_character('Legolas', 'Elf', True, True, 'Bow')
saruman = LOTR_character('Saruman', 'Wizard', False, False, 'Staff')
boromir = LOTR_character('Boromir', 'Man', True, False, 'Sword')

## I would want to collate multiple characters in a tuple as opposed to a list because a tuple is immutable
characters = (aragorn, gandalf, legolas, saruman, boromir)

## I can always create a list and modify it and then, once it's ready, convert it into a tuple

## the / placed in a function specifies that all preceding argument can only be positional

## filter function: it takes an iterable and filters it. returns an iterator

survived = filter(lambda x: x.survives, characters)

print('\nPrinting guys who survived...\n')
for item in survived:
    print(item.name)

## evaluates a logical expression and filters an iterable (could just use a list comprehension...)

sword = filter(lambda x: ('Sword' in x.weapons) or (x.weapons == 'Sword'), characters)

print('\nPrinting guys with swords...\n')
for item in sword:
    print(item.name)

## As a replacement for the filter() function I could use a generator (comprehension) and turn it into a tuple

sword_2 = tuple(character.name for character in characters if ((character.weapons == 'Sword') | ('Sword' in character.weapons)))
print('\nPrinting guys with swords again...\n')

print(sword_2)

## the map() function takes a set of iterables and applies a function to each item in the iterable. Returns an iterator
## stops when the shortest iterable is exhausted (like zip, for instance)

## kind of made useless by numpy vectorised operations and comprehensions
print(type({1, 2, 3}))


## reduce function

from functools import reduce

print(help(reduce))

## reduces a sequence to a single value according to a rule that we specify as a first argument ("accumulator")

count_survivors = reduce(lambda acc, character: acc + 1 if character.survives else acc, characters, 0)

# print(f'{} of our characters survive..')
