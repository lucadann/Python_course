## functools
import functools

class train:
    def __init__(self, stops):
        self.from = stops[0]
        self.to = stops[-1]
        self.position = stops[0]
        self.stops = stops
    
