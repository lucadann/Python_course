## decorators tutorial
## closures recap
def outer_function():
    message = 'hi'
    def inner_function():
        print(message)
    return inner_function


myfunc = outer_function()


def outer_function(msg):
    message = msg
    def inner_function():
        return message
    return inner_function

myfunc = outer_function('ciao')

myfunc()

## decorator: a function that takes another function as an argument and adds additional functionality
## as simple as can be
def decorator_function(original_function):
    def wrapper_function():
        return original_function()
    return wrapper_function

def display():
    print('display function ran')

decorated_display = decorator_function(display)

decorated_display() #runs the display function

def decorator_function(original_function):
    def wrapper_function():
        print('wrapper executed before {}'.format(original_function.__name__))
        return original_function()
    return wrapper_function

decorated_display = decorator_function(display)
print(decorated_display())

@decorator_function
def display():
    print('display function ran')
## using the @ syntax is a shorthand way of adding functionality to an existing function
## the functionality is added directly within the original function
display()

# this doesn't work if the original function has arguments


## I have to include *args and **kwargs
def decorator_function(original_function):
    def wrapper_function(*args, **kwargs):
        print('wrapper executed before {}'.format(original_function.__name__))
        return original_function(*args, **kwargs)
    return wrapper_function

@decorator_function
def display_info(name, age):
    print('{} is {} years old'.format(name, age))

## using classes as decorators
class decorator_class:
    def __init__(self, original_function):
        self.original_function = original_function
    def __call__(self, *args, **kwargs):
        print('call method executed before {}'.format(self.original_function.__name__))
        return self.original_function(*args, **kwargs)

@decorator_class
def display_info(name, age):
    print('{} is {} years old'.format(name, age))

## practical examples

## exporting data to a file location
import pandas as pd

def export_csv(original_function):
    def wrapper(path, *args, **kwargs):
        original_function(*args, **kwargs).to_csv(path)
        return original_function(*args, **kwargs)
    return wrapper
## it calls the function twice, which isn't nice
@export_csv
def ciao():
    return pd.DataFrame([1, 2, 3])

ciao(path = 'ciao.csv')
