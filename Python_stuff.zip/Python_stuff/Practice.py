# practice
import csv

with open(r"C:\Users\ludann\Desktop\Python_shit\Quarterly_data.csv") as csvfile:
    IFRS9data = list(csv.DictReader(csvfile))

# get NPL share overall
# WARNING if I call a variable "sum" I won't be able to call sum() as a functions
# careful with variable names
list1 = [float(i["GROSS_EXPOSURE"]) for i in IFRS9data]
list2 = [float(i["GROSS_EXPOSURE"]) for i in IFRS9data if i["STAGE"] == "Stage 3"]
sum(list2)/sum(list1)
# get BANK i's NPL share each quarter in dictionary format
def get_NPL_ts(bank, info):
    bankdata = [i for i in IFRS9data if i["BANK"] == bank]
    quarters = set([obs["QUARTER"] for obs in bankdata])
    items = []
    for i in quarters:
        total_exp = sum([float(obs[info]) for obs in bankdata
            if obs["QUARTER"] == i])
        list2 = [float(obs[info]) for obs in bankdata
            if obs["QUARTER"] == i
            and obs["STAGE"] == "Stage 3"]
        items.append([i, sum(list2)/total_exp])
    return dict(items)
# rudimentary filter

# python uses lexical scoping like R:
# it searches for variables in the environment in which the function was defined
def func1(x):
    return x + 1

def func2(x):
    def func1(y):
        return y*1
    return func1(x) + 1
# func2() calls func1() as defined inside the function
def func3(x):
    return func1(x) + 1
# func3() does not define func1 so it uses the one defined in the ".GlobalEnv"


# more practice
for segment in set([i["SEGMENT"] for i in IFRS9data]):
    avg = np.array([float(i["GROSS_EXPOSURE"]) for i in IFRS9data
        if i["SEGMENT"] == segment]).mean()
    print("Average exposure for the {} segment is {}".format(segment, avg))

for bank in set([i["BANK"] for i in IFRS9data]):
    avg = np.array([float(i["GROSS_EXPOSURE"]) for i in IFRS9data
        if i["BANK"] == bank]).mean()
    print("{}'s average exposure is {}".format(bank, avg))
