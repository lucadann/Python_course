# BIR corporate portfolio

import os
import numpy as np
import pandas as pd

def cls():
    os.system("cls")

BIR_CORPORATE = pd.read_excel("C:/Users/ludann/Documents/ISP FBCRM/" +
    "IFRS9/Report KPMG/BIR/Corporate portfolio 30.06.18_ISP.xlsx",
    sheet_name = 1, skiprows = [0, 1])

BIR_CORPORATE_2 = pd.read_excel("C:/Users/ludann/Documents/ISP FBCRM/" +
    "IFRS9/Report KPMG/BIR/Corporate portfolio 30.06.18_ISP.xlsx",
    sheet_name = 0)
BIR_CORPORATE_2.set_index("ID_CLIENT", inplace = True)
BIR_CORPORATE_2.ID_CLIENT.unique().size == len(BIR_CORPORATE_2)
## True
BIR_CORPORATE.set_index("ID_CLIENT").loc[BIR_CORPORATE_2.index]
BIR_CORPORATE_2.reset_index(inplace = True)

np.sum([OBS in BIR_CORPORATE.ID_CLIENT.unique()
    for OBS in BIR_CORPORATE_2.ID_CLIENT])
## id_clients are the same

## QUESTION 1: 20 counterparties with different segmentation
BIR_CORPORATE.ID_CLIENT_TYPE.unique()

(BIR_CORPORATE.groupby("ID_CLIENT")["ID_CLIENT_TYPE"].
    apply(lambda x: x.unique().size)).sum()
## ok, each client ID has a unique client type

CLIENT_TYPES = (BIR_CORPORATE.groupby("ID_CLIENT")["ID_CLIENT_TYPE"].
apply(lambda x: x.unique()[0])).sort_index()

CLIENT_TYPES_2 = (BIR_CORPORATE_2.groupby("ID_CLIENT")["TYPE"].
apply(lambda x: x.unique()[0])).sort_index()

CLIENT_TYPES.loc[CLIENT_TYPES_2 != CLIENT_TYPES]
## The majority are SME medium clients, only one leasing client
(BIR_CORPORATE.set_index("ID_CLIENT").
loc[CLIENT_TYPES.loc[CLIENT_TYPES_2 != CLIENT_TYPES].index,
    "ID_PRODUCT"].unique())
## ID_PRODUCT is "LeasingCorporate" for all counterparties

## QUESTION 2
(BIR_CORPORATE_2.where(BIR_CORPORATE_2["Rating ISP"].notna()).
loc[:, ["ID_CLIENT", "CLIENT_NAME", "Rating ISP", "TYPE", "BIR rating 30.06.2018 "]].
dropna())
## last question
## convert to RUR
for column in ["TOTAL_IFRS_AMOUNT", "PROV_BALANCE_CCY", "PROV_OFFBALANCE_CCY"]:
    BIR_CORPORATE[column] = BIR_CORPORATE[column]*BIR_CORPORATE["FX_RATE"]

EXP_COMPARE = pd.DataFrame({"EXP_RUR_1" : EXP_BY_CLIENT,
    "EXP_2" : EXP_2,
    "DIFF" : EXP_BY_CLIENT - EXP_2})
EXP_COMPARE.to_excel("C:/Users/ludann/Desktop/BIR_CORPORATE_PERF.xlsx")

DIFF[DIFF.abs() > 0]

EXP_COMPARE["DIFF"] = EXP_COMPARE["TOTAL EXPOSURE"] - EXP_COMPARE["EXPOSURE_RUR"]
EXP_COMPARE[EXP_COMPARE["DIFF"].abs() > 1].shape[0]

def check_one_to_one(data, variable, match):
    matches = (data.groupby(variable)[match].
        apply(lambda x: x.unique().size))
    if matches.loc[matches != 1].empty:
        print("One to one match between {} and {}".format(variable, match))
    else:
        print(match)
        return matches.loc[matches != 1]

## version with no side effects to plug into make_client_level()
def check_one_to_one_aux(data, variable, match):
    matches = (data.groupby(variable)[match].
        apply(lambda x: x.unique().size))
    if matches.loc[matches != 1].empty:
        return None
    else:
        return matches.loc[matches != 1]


def make_client_level(data, client_id, aggregate, f = np.sum, keep_cols = []):
    checklist = []
    for column in data:
        try:
            if check_one_to_one_aux(data, client_id, column) == None:
                checklist.append(column)
        except ValueError:
            continue
    cols_to_keep = [column for column in keep_cols
        if column in checklist]
    cols_to_discard = [column for column in keep_cols
        if column not in checklist]
    if len(cols_to_discard) > 0:
        print("The following columns were dropped because they have more " +
            "than one value for each " + client_id + ": " + str(cols_to_discard))
    cols_to_keep.append(client_id)
    return (data.groupby(cols_to_keep)[aggregate].
        apply(f).reset_index().set_index(client_id))


BIR_CORPORATE_byclient = make_client_level(BIR_CORPORATE, "ID_CLIENT",
["TOTAL_IFRS_AMOUNT", "PROV_BALANCE_CCY", "PROV_OFFBALANCE_CCY"],
keep_cols = ["CLIENT_NAME", "ID_CLIENT_TYPE", "ID_IMP_STAGE"])

(BIR_CORPORATE_byclient.
to_excel("C:/Users/ludann/Desktop/BIR_CORPORATE_byclient.xlsx"))
