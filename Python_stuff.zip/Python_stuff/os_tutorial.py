## os module tutorial
import os

a = os.getcwd()
print(a)
print(type(a)) # string

os.chdir('C:/Users/ludann/Desktop')
print(os.getcwd())

print(os.listdir())

os.makedirs('Test')
## could also use mkdir, but it doesn't allow to create paths

os.rename('Test', 'Fuck you') # works both for files and directories
## I can also use rename to move files

os.rmdir('Fuck you')
# or os.removedirs() to delete recursively

os.system('echo "viva la figa" > vlf.txt')

os.stat('vlf.txt') # prints out file stats
# including size and last modification time in "epoch" format
os.stat('vlf.txt').st_mtime

from datetime import datetime
last_mod_vlf = os.stat('vlf.txt').st_mtime
datetime.fromtimestamp(last_mod_vlf)

## os.walk delivers a three-valued tuple (?)

for dirpath, dirnames, filenames in os.walk("C:/Users/ludann/Desktop/Python_shit"):
    print("Current Path:", dirpath)
    print("Directories:", dirnames)
    print("Files:", filenames)

# os.walk prints the files and folders in the specified directory and does
# the same for all directories in the tree

## environment variables
os.environ.get('HOME')

file_path = os.path.join(os.environ.get('USERPROFILE'), r'Desktop\yeee')
print(file_path)
# creates a path as string (?)

os.path.basename("C:/Users/ludann/Desktop/vlf.txt")
os.path.basename(r'C:\Users\ludann\Desktop\vlf.txt') # works with raw text too
os.path.dirname('C:/Users/ludann/Desktop/vlf.txt')

os.path.split('C:/Users/ludann/Desktop/vlf.txt')

os.path.exists('C:/Users/ludann/Desktop/vlf.txt') # true

os.path.isdir('C:/Users/ludann/Desktop')
os.path.isfile('C:/Users/ludann/Desktop')

os.path.splitext('C:/Users/ludann/Desktop/vlf.txt')
os.path.splitext('vlf.txt')
