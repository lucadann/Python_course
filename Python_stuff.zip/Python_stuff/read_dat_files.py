## files and the operating system

f = open("C:/Users/ludann/Desktop/test1.txt")

for line in f:
    print(line)
f.read(10) ## reads first lines and then "deletes" them from f,
# once lines are read or printed they get canceled (but not lost)
f.tell() # tells the position in the file (how much I've read so far)
f.seek(0) # rewinds file back to specified position
#(or fast forwards to specified position)
with open("C:/Users/ludann/Desktop/test1.txt") as f:
    lines = [x for x in f]
## this statement copies lines in the list with their EOL markers ("\n")
with open("C:/Users/ludann/Desktop/test1.txt") as f:
    lines = [x.rstrip() for x in f]
## this specification does not remove newlines
with open("C:/Users/ludann/Desktop/test1.txt") as f:
    lines_2 = f.readlines()
## reading lines in raw binary format (where newlines are denoted as '\r\n')
with open("C:/Users/ludann/Desktop/test1.txt", "rb") as f:
    lines_2 = f.readlines()
[x.decode("utf8") for x in lines_2]
## doesn't work because of italian characters???
lines_2[1].decode("utf8").rstrip()
##
globals() #shows contents of global environment as dictionary
globals()["test_var"] = "how to assign using strings"
import re
## function to view contents of global environment by class
def view_globals(_class = None, list = False): ##_class must be a string
    name_class = [(name, str(type(object)))
        for name, object in globals().items()]
    final_list = []
    for names, classes in name_class:
        if names == "view_globals":
            continue
        elif _class == None:
            final_list.append(names)
            print(names + ":", classes)
        elif bool(re.search(_class, classes)) == True:
            final_list.append(names)
            print(names)
        else:
            continue
    if list == True:
        return final_list

def print_lines(file_as_list, n = 10):
    count = 0
    for line in file_as_list:
        count += 1
        if count <= n:
            print(line)
        else:
            break
