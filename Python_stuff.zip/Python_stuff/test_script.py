## remember to use print() to show output on the console
# and to always save files before running

import pandas as pd
import numpy as np

print(pd.DataFrame(np.random.randn(3000, 3)))
import os

print(os.system("dir"))
