## multiprocessing module
import os
import time
from multiprocessing import Process, current_process

def square(numbers, ):
    for number in numbers:
        time.sleep(0.5)
        result = number**2
        print(f'{number} squares to {result}')
    # process_id = os.getpid()
    # process_id = current_process().name
    # print(f'Process ID : {process_id}') # prints the process ID assigned to the call by the operating system


if __name__ == '__main__':
    numbers = range(100)
    for i in range(50):
        process = Process(target=square, args = (,)) ## args must be a tuple
        processes.append(process)
        process.start()

## I can also get the process ID by using the current_process function
## they don't necessarily come out in sequential numbers
