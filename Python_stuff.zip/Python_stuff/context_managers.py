# context managers

# with statement relies on the __enter__ and __exit__ methods!

## class
import sys
class recursion_limit:
    def __init__(self, new_limit):
        self.new_limit = new_limit
        self.old_limit = sys.getrecursionlimit()

    def __enter__(self):
        sys.setrecursionlimit(self.new_limit)

    def __exit__(self, exc_type, exc_val, traceback):
        sys.setrecursionlimit(self.old_limit)

print('\nExample using classes')
print(sys.getrecursionlimit())
with recursion_limit(10000):
    print(sys.getrecursionlimit())

print(sys.getrecursionlimit(), '\n')

## decorator + function
from contextlib import contextmanager

@contextmanager
def recursion_limit_func(new_limit):
    try:
        old_limit = sys.getrecursionlimit()
        sys.setrecursionlimit(new_limit)
        yield
    finally: # teardown code is run regardless of any exceptions
        sys.setrecursionlimit(old_limit)

print('Example using decorators')
print(sys.getrecursionlimit())
with recursion_limit_func(3000):
    print(sys.getrecursionlimit())

print(sys.getrecursionlimit())
