def view_globals(browse_for = None): ##browse_for must be a string
    from pandas import Series
    name_type = Series()
    for name in globals():
        if name == "view_globals2":
            continue
        else:
            name_type[name] = str(type(globals()[name]))
    if browse_for == None:
        return name_type
    else:
        return (name_type.
            loc[name_type.str.contains(browse_for)])
