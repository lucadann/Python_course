## REGEX in PYTHON

import re

# multiline string
text_to_search='''
abc
hi
my name is luca
fuck you
12345asafasfabc
ciucciamelo
viva la fregna
'''

# raw strings don't treat backslashes in any special way (e.g. as tabs or newlines)

string1 = 'this\nis\nSparta'
print(string1)
string1_raw = r'this\nis\nSparta'
print(string1_raw)


pattern = re.compile(r'abc')

# finditer finds ALL of the matches and creates an iterator (not subscriptable)
matches = pattern.finditer(text_to_search)

for match in matches:
    print(match)

for match in matches:
    print(match.span())

# escaping characters

pattern = re.compile(r'\.') # the period is a special character so I need to 'escape' it using the backslash

# the dot matches every character except newlines ('\n')

# \d matches every digit between zero and nine

# \D matches anything that is not a digit

## essentially, capital letters 'negate' the lowercase version

# \w matches anything that is letters, digits and underscores

# \W matches anything that is not a word

# \s matches any whitespace

with open('NACE_codes.txt') as f:
    NACE = f.read()

pattern = re.compile('[A-Z] - ')

matches = pattern.finditer(NACE)

for match in matches:
    print(match)

## anchors don't match characters, they match invisible positions before or after characters

# \b is a word boundary (whitespace or non-alphanumeric character)

pattern = re.compile(r'\ba')

match = pattern.finditer("aldameiro fai cagare abramo strega avida")

for word in match:
    print(word)

# ^beginning of a string
# $ end of a string

NACE_list = NACE.split('\n')

pattern = re.compile(r'^A')


for match in pattern.finditer('ACCIAIERIA'):
    print(match)

pattern = re.compile(r'^A')

for item in NACE_list:
    if bool(re.search(pattern, item)):
        print(item)

## within square brackets, dots are interpreted literally (no need for "excaping")

numbers = '''3333700432
3343511398
3409217900
3440889564
3402359292
3351145232
3291212456'''

pattern = re.compile(r'3[32]\d{8}')

for match in pattern.finditer(numbers):
    print(match)

## - is a special character too, if placed between two characters (it specifies a range)

pattern = re.compile(r'3\d[0-4]\d{7}')

for match in pattern.finditer(numbers):
    print(match)

## ^, if placed within a character set at the beginning negates the set
# I don't need to excape characters within a character set
## block comment out: ctrl+shift+7
pattern = re.compile(r'3[^32]\d{8}')

for match in pattern.finditer(numbers):
    print(match)

    ## quantifiers, multiple characters at a time
# need to be placed AFTER the pattern
# *: zero or more
# +: one or more
# ?: zero or one
# {3} exact number
# {3, 4} range of numbers {min, max}

names = '''Mr. Dann
Mrs Mazzotti
Ms Mazzotti
Mr Scartezzini'''

pattern = re.compile(r'Mr\.?\s\w*')

for match in pattern.finditer(names):
    print(match)
# only matches Mr

## groups allow to match several different patterns

pattern = re.compile(r'M(r|s|rs)\.?\s\w*')
## | stands for "or"
for match in pattern.finditer(names):
    print(match)

def get_subcodes(letter):
    pattern = re.compile(r'{}((\d)+|\s)(\.[0-9]+)*'.format(letter))
    for match in pattern.finditer(NACE):
        print(match)

# returns all NACE codes beginning with a given letter

emails = '''
lucadann93@gmail.com
ldann@sts.deloitte.it
luca.dann@deloitte.it
'''
pattern = re.compile(r'[\w+\.]*@(\w+\.)+\w+')
## matches all types of emails

## how to capture information from groups

urls = '''
https://www.google.com
http://coreyms.com
https://youtube.com
https://www.nasa.gov
'''
# suppose we only want the domain and the top-level domain
pattern = re.compile(r'https?://(www\.)?(\w+)(\.\w+)')
## the regex divided in three groups

for match in pattern.finditer(urls):
    print(match.group(0)) # group 0 is the entire match
# match[0] gives the same result
for match in pattern.finditer(urls):
    print(match.group(2, 3))

## back references for accessing groups
subbed_urls = pattern.sub(r'\2\3', urls)
print('AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAa')
print(subbed_urls)


## other python methods
matches = pattern.findall(urls)
## divides results according to the groups specified in the pattern
## and only prints out group

## match determines if the regex matches the beginning of the string
sentence = 'Ciucciami le palle'

pattern = re.compile(r'Ciuccia')

matches = pattern.match(sentence)
# returns a single match object
print(matches)

# search searches the entire string
pattern = re.compile(r'palle')

matches = pattern.search(sentence)

print(matches)

## if search() and match() don't find a match, they just return None

## flags

pattern = re.compile(r'start', re.IGNORECASE) # case-insensitive

pattern = re.compile(r'start', re.I) # equivalent

## placeholders

'ciao %s io' %'sono' # %s is specific for strings (?)

'ciao %d bella' %6 # %d is specific for integers

'%f percento grandi successi' %99.9 # %f is specific for floating point numbers

## continue
