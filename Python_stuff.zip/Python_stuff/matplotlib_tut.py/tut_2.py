## matplotlib_tut 2

import pandas as pd
import numpy as np
from matplotlib import pyplot as plt
from datetime import datetime

db = pd.read_csv(r'C:\Users\ludann\Desktop\Fantacalcio\data\quotazioni\DB_quotazioni.csv', sep = ';')

db['Data'] = db['Data'].apply(lambda x: datetime.strptime(x, '%Y-%m-%d'))

print(db['Data'].unique()[0])

db.sort_values('Data', inplace = True)
#
# plt.style.use('fivethirtyeight')
#
# ronaldo_ts = db.loc[db['Nome'] == 'CRISTIANO RONALDO']
#
# plt.plot(ronaldo_ts['Data'].apply(lambda x: f'{x.year}-{x.month}-{x.day}' ), ronaldo_ts['Quotazione_attuale'])
# plt.show()
#

## bar charts
## average team level
db_most_recent = db.where(db['Data'] == db['Data'].max())
avg_team = db_most_recent.groupby('Squadra')['Quotazione_attuale', 'Quotazione_iniziale'].mean()
avg_team.sort_values('Quotazione_attuale', inplace=True)
# print(avg_team)
width = 0.3

x_indeces = np.arange(len(avg_team.index))

plt.bar(x_indeces + width, avg_team['Quotazione_attuale'], width = width, label = 'Quotazione attuale')
plt.bar(x_indeces, avg_team['Quotazione_iniziale'], width = width, label = 'Quotazione iniziale')


plt.xticks(ticks=x_indeces, labels=[item[:3] for item in avg_team.index])
plt.legend()

plt.title('Quotazioni attuali vs. Iniziali per squadra')
plt.xlabel('Squadra')
plt.ylabel('Quotazioni')

plt.show()

## plot
avg_role = db_most_recent.groupby(['Ruolo', 'Squadra'])['Quotazione_attuale', 'Quotazione_iniziale'].sum()
q_tot_squadra = avg_role['Quotazione_attuale'].sum(level='Squadra')
q_tot_squadra.name = 'Q_tot_squadra'
avg_role = avg_role.join(q_tot_squadra, on='Squadra')
avg_role.sort_values('Q_tot_squadra', inplace = True)
print(avg_role)

left = 0
for role in ['P', 'D', 'C', 'A']:
    avg_role_i = avg_role.loc[role]
    height_value = avg_role_i['Quotazione_attuale']
    plt.barh([name[:3] for name in avg_role_i.index], height_value, left = left, label = role)
    left += height_value


plt.legend()
plt.show()

## proportional
avg_role['Quotazione_proporzionale'] = avg_role['Quotazione_attuale']/avg_role['Q_tot_squadra']

left = 0
for role in ['P', 'D', 'C', 'A']:
    avg_role_i = avg_role.loc[role]
    height_value = avg_role_i['Quotazione_proporzionale']
    plt.barh([name[:3] for name in avg_role_i.index], height_value, left = left, label = role)
    left += height_value


plt.legend()
plt.show()


## ciao

plt.scatter(db_most_recent['Quotazione_attuale'], db_most_recent['Quotazione_iniziale'], c = db_most_recent['Squadra'].apply(lambda x: 'Red' if x == 'Juventus' else 'Green'), alpha = 0.3)
for i in db.index:
    player = db_most_recent.loc[i]
    if player['Squadra'] != 'Milan' or player['Ruolo'] != 'A':
        continue
    else:
        plt.text(player['Quotazione_attuale'] + 0.2, player['Quotazione_iniziale'] + 0.2, player['Nome'])

plt.xlabel('Quotazione attuale')
plt.ylabel ('Quotazione iniziale')
plt.show()
