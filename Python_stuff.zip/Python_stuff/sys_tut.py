## sys tutorial
import sys

# sys.stderr.write('test')
# sys.stderr.flush()
# sys.stdout.write('This is output\n')
# sys.stderr.flush()
#
# print(sys.argv)
# print(type(sys.argv))
# # list of arguments
#
# if len(sys.argv) > 1:
#     print(sys.argv[1])
# ## when I run the program from the command line it will print the second argument
# ### used to pass arguments to a python program from the regular command line
# print(dir(sys))


def func1(root, exponent):
    print(f'returning {root} to the power of {exponent}....\n')
    try:
        result = float(root)**float(exponent)
    except ValueError as a:
        print(a)
    else:
        return result

try:
    arg_list = sys.argv[1:]
except TypeError:
    print('You fucked up!')

try:
    print(func1(arg_list[0], arg_list[1]))
except:
    print('Fuck you!')
    print(arg_list)

import sys



sys.executable
## says where I am on the system

sys.builtin_module_names
##shows all builtin modules (why the underscore??)

sys.modules
## prints a dictionary with all my modules

sys.platform
## tells me the operating system I'm running on: returns 'win32'
