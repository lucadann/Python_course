#impact assessment
import numpy as np
import pandas as pd
import os
class Impact_assessment():
    @classmethod
    def from_file(cls, path, nodata = False, sheet_name = 2, usecols = "F:K", skiprows = 6,
        nrows = 48, header = None):
        filename = os.path.splitext(os.path.basename(path))[0]
        split = filename.split("_")
        bank = split[0]
        quarter = pd.to_datetime(split[-1], format = "%d%m%Y")
        if nodata== True:
            return cls(None, bank, quarter)
        else:
            df = pd.read_excel(path, sheet_name = sheet_name, usecols = usecols,
                skiprows = skiprows, nrows = nrows, header = header)
            df.index = pd.MultiIndex(levels=[['Bonds', 'Loans'],
                    ['Banks', 'Corporate', 'Intra-group Exposures', 'Mortgages',
                        'Other Retail', 'PSE', 'Public Entities', 'SME Retail', 'Sovereign'],
                    ['HTM', 'AFS'], ['Stage 1', 'Stage 2', 'Stage 3']],
                labels = [[0,]*26 + [1,]*22,
                    [8,]*6 + [5,]*6 + [0,]*6 + [2,]*2 + [1,]*6 + [8,]*3 + [6,]*3 +
                        [0,]*3 + [2,] + [1,]*3 + [7,]*3 + [4,]*3 + [3,]*3,
                    ([1,]*3 + [0,]*3)*3 + [1, 0] + [1,]*3 + [0,]*3 + [-1]*22,
                    [0, 1, 2]*6 + [0,]*2 + [0, 1, 2]*5 + [0,] + [0, 1, 2]*4],
                names=['PRODUCT_TYPE', 'SEGMENT', 'BOND_TYPE', 'STAGE'])
            df.columns = pd.MultiIndex(levels = [["EXPOSURE", "PROVISION"],
                ["OnBal", "OffBal", "Total"]], labels = [[0,]*3 + [1,]*3,
                [0, 1, 2]*2])
            return cls(df, bank, quarter)
    def __init__(self, data, bank, quarter):
        self.data = data
        self.bank = bank
        self.quarter = quarter
    def __repr__(self):
        return "Impact_assessment({}, {}, {})".format(self.data, self.bank, self.quarter)

class Impact_assessment_db:
    def __init__(self, data = pd.DataFrame()):
        self.bank_quarter = []
        self.entry_log = pd.Series()
        self.data = data
    @classmethod
    def from_csv(cls, path, **kwargs):
        df = pd.read_csv(path, **kwargs)
        return cls(data = df)
    def enter_data(self, directory):
        for file in os.listdir(directory):
            Imp_ass_test = Impact_assessment.from_file(file, nodata = True)
            if (Imp_ass_test.bank, Imp_ass_test.quarter) in self.bank_quarter:
                ## not nice that it reads the file for nothing
                print("{} data as of {} already read".format(Imp_ass_test.bank, Imp_ass_test.quarter))
                continue
            else:
                Imp_ass = Impact_assessment.from_file(file)
                Imp_ass.data = pd.concat([Imp_ass.data], keys=[Imp_ass.quarter], names = ["QUARTER"])
                Imp_ass.data = pd.concat([Imp_ass.data], keys=[Imp_ass.bank], names = ["BANK"])
                self.data = self.data.append(Imp_ass.data)
                self.bank_quarter.append((Imp_ass.bank, Imp_ass.quarter))
                self.entry_log[pd.to_datetime("today")] = "Entered {} data for {}Q{}".format(Imp_ass.bank, Imp_ass.quarter.year, Imp_ass.quarter.quarter)
    def __repr__(self):
        return("Impact_assessment_db({} observations)".format(self.data.shape[0]))
