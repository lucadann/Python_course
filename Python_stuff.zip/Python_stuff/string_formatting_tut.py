## string formatting

class Fake:
    def __init__(self, firstname, lastname):
        self.firstname = firstname
        self.lastname = lastname
## using format print class attributes
fake1 = Fake('Luca', 'Dann')
print('My name is {0.firstname} {0.lastname}'.format(fake1))

## using format to print dictionary items
fake1_dict = {'firstname' : 'Luca', 'lastname' : 'Dann'}
print('{firstname} {lastname}'.format(**fake1_dict))

## keyword arguments
sentence = 'My name is {name} and I am {age} years old'.format(name='Luca', age=26)
print(sentence)


## formatting and printing out numbers
## the colon indicates that I'm setting a format
for i in range(11):
    # zero-padding
    sentence = 'The value is {:02}'.format(i)
    print(sentence)

import random

randos = (random.gauss(0, 1) for i in range(10))

for i in randos:
    # Setting decimal places
    sentence = 'The value is {:.2f}'.format(i)
    print(sentence)

## inserting decimal separators

randos2 = (random.uniform(0, 1000000000) for i in range(50))

for i in range(10):
    ## decimal separators and 0 decimal places
    sentence = 'The value is {:,.0f}'.format(next(randos2))
    print(sentence)

import datetime

my_date = datetime.datetime(2019, 7, 6, 13, 50, 30)

print(my_date)

## check out date formatting options on the documentation
# again, the colon indicates that I want to format my values
sentence = '{:%B %d, %Y}'.format(my_date)
print(sentence)

## day of the week

sentence = '{0:%B %d, %Y} fell on a {0:%A} and was the {0:%j}th day of the year'.format(my_date)
print(sentence)

## using f-strings
first_name = 'Luca'
last_name = 'Dann'

sentence = f'My name is {first_name} {last_name}'
print(sentence)

# I can pass formats using the colon from within the curly braces
sentence = f'The value is {1:.2f}'
print(sentence)

## printing dictionary values
person = {'name' : 'Marina', 'age' : 23}

# I have to differentiate the quotes within the f-string so they won't conflict with each other
sentence = f'My name is {person["name"]} and I am {person["age"]} years old'
print(sentence)

calculation = f'4 times 11 is equal to {4*11}'
print(calculation)

for n in range(1, 11):
    # zero-padding
    sentence = f'The value is {n:02}'
    print(sentence)

## floating point numbers
sentence = f'Pi is equal to {random._pi:.4f}'
print(sentence)
