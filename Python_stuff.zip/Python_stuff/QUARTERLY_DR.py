## default rate time horizon
import os
import pandas as pd
import numpy as np

def cls():
    os.system("cls")

defaults = pd.DataFrame(index = range(0, 200),

    columns = pd.date_range("2018-12-31", freq = "M", periods = 1+12*7))

for date, i in zip(defaults.columns,
    np.random.uniform(0, 0.4, 85)):
    defaults[date] = np.random.binomial(1, i, 200)

defaults = (defaults.
append(pd.DataFrame(np.array([0,]*800*defaults.shape[1]).
    reshape(800, defaults.shape[1]),
    index = range(200, 1000),
    columns = defaults.columns)))

def get_dr(df, time_horizon, DR_freq):
    data_freq = df.columns.freq
    index_dates = pd.date_range(start = df.columns[time_horizon],
        periods = df.shape[1] - time_horizon, freq = data_freq)
    denoms_list = [df.loc[df[i] == 0].shape[0] for i in
        index_dates.shift(-time_horizon, data_freq)]
    nums_list = list()
    for i, j, k in zip(index_dates.shift(-time_horizon, data_freq),
        index_dates.shift(-(time_horizon-1), data_freq), index_dates):
        ith_element = (df.
            loc[df[i] == 0].
            loc[df.loc[:, j:k].sum(axis = 1) > 0].
            shape[0])
        nums_list.append(ith_element)
    return (pd.DataFrame({"DR_" + str(time_horizon) + "periods" :
        np.divide(nums_list, denoms_list)}, index = index_dates).
        loc[index_dates.shift(0, DR_freq).unique()])

defaults_2 = pd.DataFrame(index = range(0, 1000),
    columns = pd.date_range("2018-12-31", freq = "M", periods = 85))

for date, i in zip(defaults_2.columns,
    np.random.uniform(0, 0.4, 85)):
    defaults_2[date] = np.random.binomial(1, i, 1000)

defaults_2 = (defaults_2.
append(pd.DataFrame(np.array([0,]*10000*defaults_2.shape[1]).
    reshape(10000, defaults_2.shape[1]),
    index = range(1000, 11000),
    columns = defaults_2.columns)))
