
def myfunc(x):
    yield from x

if __name__ == '__main__':
    mygen = myfunc([0, 1, 2, 3, 4])
    for i in mygen:
        print(item)
