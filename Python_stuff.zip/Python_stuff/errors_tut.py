## try except tut

# printing python error text
try:
    list1
except NameError as a:
    print(a)


## else runs code that needs to be executed if the try doesn't raise an exception
## it's good practice to only put in the try block the stuff that we want to catch
list1 = [1, 2, 3]
try:
    list1.append(1)
except NameError as a:
    print(a)
else:
    print(list1)
finally:
    print('Parenzooooooo!!!')
