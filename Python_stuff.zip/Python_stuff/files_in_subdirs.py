
import os
import sys

def grab_files_subdirs(source_dir, destination, criterion=True):
    list1 = []
    walk = os.walk(source_dir)
    for level in walk:
        level_dir = level[0]
        for item in level[1:]:
            for file in item:
                if criterion(file):
                    file_path = os.path.join(level_dir, file)
                    if file in list1:
                        new_name = f'{os.path.splitext(file)[0]}_1.{os.path.splitext(file)[1]}'
                        new_file_path = os.path.join(destination, new_name)
                    else:
                        new_file_path = os.path.join(destination, file)
                    try:
                        os.rename(file_path, new_file_path)
                    except FileNotFoundError:
                        os.mkdir(destination)
                        os.system(f'xcopy {file_path} {destination}')
            # list1.extend([file for file in item if criterion(file)])
    print(os.listdir(destination))

if __name__ == '__main__':
    args = sys.argv[1:]
    source_dir = args[0]
    destination = args[1]
    try:
        criterion = eval(args[2])
    except:
        criterion = True

    grab_files_subdirs(source_dir, destination, criterion)
