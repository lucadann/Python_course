from dashboards import app
    # user-post relationship (one-to-many)

# run by setting flask_app environment variable and running the command "flask run"
if __name__=='__main__':
    app.run(debug=True)
