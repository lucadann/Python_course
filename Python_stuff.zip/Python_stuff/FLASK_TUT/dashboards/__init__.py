from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from flask_bcrypt import Bcrypt

# initialise app
app = Flask(__name__)

# set configuration values for the application
app.config['SECRET_KEY'] = 'a351fbfe612fe6c74021367264736284'

# object relational manager
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///site.db' # three slashes indicate relative path

# creating an SQLAlchemy instance
db = SQLAlchemy(app)

# bcrypt
bcrypt = Bcrypt(app)

from dashboards import routes
