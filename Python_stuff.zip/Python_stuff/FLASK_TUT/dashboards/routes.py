from dashboards.models import User, Post
from dashboards.forms import Registration, Login
from dashboards import app, bcrypt, db
from flask import render_template, url_for, flash, redirect

posts = [
    {
        'author':'Luca Dann',
        'title': 'Blog Post 1',
        'content': 'Blah Blah Blah',
        'date_posted': 'October 20th, 2020'
    },
    {
        'author':'Luca Dann',
        'title': 'Blog Post 2',
        'content': 'Blah Blah Blah',
        'date_posted': 'October 21st, 2020'
    }
]

# a simple page that says hello
@app.route('/')
@app.route('/home')
def home():
    return render_template('home.html', posts=posts) # reads templates from a folder called "templates"

@app.route('/about')
def about():
    return render_template('about.html', title='About')

@app.route('/register', methods=['GET', 'POST'])
def register():
    form = Registration()
    # validation check
    if form.validate_on_submit():
        hashed_password = bcrypt.generate_password_hash(form.password.data).decode('utf-8')
        user = User(username=form.username.data, email=form.email.data, password=hashed_password)
        db.session.add(user)
        try:
            db.session.commit()
        except:
            # db.session.delete(user)
            flash(f'Fuck you!') # bootstrap class
        else:
            flash(f'Account created for {form.username.data}', 'success') # bootstrap class
            return redirect(url_for('login')) #name of the function, not the URL
    return render_template('register.html', title='Register', form=form)

@app.route('/login')
def login():
    form = Login()
    return render_template('login.html', title='Login', form=form)
