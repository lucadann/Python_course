## scoping

# LEGB: Local, Enclosing, Global, Bulit-In

# this is the order in which Python searches for variables

## Global vs. Local variables

x = 'global x'

def test():
    y = 'local y'
    print(y)

# the test function looks for y within the function
test()

## the y variable only lives within the function where it was defined,
# so if I look for y outside of the function I won't find it

def test():
    global x
    x = "glocal x"
    print(x)

print(x)
test()

## do not overuse the global statement

def test(z):
    # z (the function argument) is a local variable
    print(z)

## built-in scope: names that are pre-assigned in python
dir(__builtins__)
## python does not bar us from overwriting builtin objects, but doing so is risky
# because Python looks in the global scope before it looks into the Built-Ins scope

## Enclosing scope: has to do with nested function
def outer():
    x = 'outer x'
    def inner():
        x = 'inner x'
        print(x)
    inner()
    print(x)

outer()

# the outer() function is an enclosing function to the inner() function
# when I set x in the inner function, it doesn't affect the x that I set in the
# outer function

# the enclosing scope equivalent of the global statement is the nonlocal statement
# the nonlocal statement allows us to work with the local variables of enclosing functions
def outer():
    x = 'outer x'
    def inner():
        nonlocal x
        x = 'inner x'
        print(x)
    inner()
    print(x)

outer()

x = "global x"

def outer():
    x = 'outer x'
    def inner():
        x = 'inner x'
        print(x)
    inner()
    print(x)

outer()
print(x)
