# corey SQLITE tutorial
from OOP_Tutorial_CS import Employee

# Luca = Employee('Luca', 'Dann', 1500)
#
# print(Luca.last)

## creating an Employee SQL database

#
import sqlite3

# connection object representing the database
  # could pass in a file or create an in-memory database, here we're creating a file
# if the file already exists, then it "connects" to it.

# creating a cursor object for SQL commands
c = conn.cursor() # ???

# executing SQL command to create a table
# c.execute("DROP TABLE employees") #use if running tutorial multiple times using disk DBs
c.execute("""
    CREATE TABLE employees (
        first text,
        last text,
        pay integer
        )
""")

# c.execute("DELETE FROM employees")

c.execute("INSERT INTO employees VALUES('Luca', 'Dann', 30000)")

c.execute("SELECT * FROM employees WHERE last='Dann'")

print(c.fetchall())
# other options are fetchone (first instance) fetchmany (n instances)

conn.commit() # commits the current transaction???

emp_1 = Employee('John', 'Doe', 30000)
emp_2 = Employee('Jane', 'Doe', 30000)

### do not insert using string formatting
c.execute("INSERT INTO employees VALUES (?, ?, ?)",
    (emp_1.first, emp_1.last, emp_1.pay))


## using dictionaries, more readable!!
c.execute("INSERT INTO employees VALUES (:first, :last, :pay)",
    {'first': emp_2.first, 'last': emp_2.last, 'pay': emp_2.pay})

c.execute("SELECT * FROM employees")

print(c.fetchall())
# other options are fetchone (first instance) fetchmany (n instances)

## pythonic implementation
def insert_emp(emp):
    ## do connections operate like context managers???
    # yes, use with statement to automatically connect
    with conn:
        c.execute("INSERT INTO employees VALUES (:first, :last, :pay)", emp.__dict__)

emp_3 = Employee('Jane', 'Austen', 30000)

insert_emp(emp_3)


def query(query):
    c.execute(query)
    return c.fetchall()

pay_sum = query("SELECT avg(pay) FROM employees")

print(pay_sum)

conn.close()
