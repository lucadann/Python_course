# exercises with NACE codes

with open('NACE_codes.txt') as file:
    NACE = file.read()

NACE_list = NACE.split('\n') # don't use raw strings
NACE_list = [item.strip() for item in NACE_list] # removes whitespace
# at the beginning and end of each element in the list

import re

def find_codes(code):
    pattern = re.compile(r'{} - .+\n'.format(code))
    match = pattern.search(NACE)
    return NACE[match.span()[0]:match.span()[1]].rstrip()

def search_byword(word, whole_word = False):
    if whole_word:
        pattern = re.compile(r'[A-Z](\.|\d)*\s-.*\W{}\W.*\n'.format(word), re.I)
    else:
        pattern = re.compile(r'[A-Z](\.|\d)*\s-\s.*{}.*\n'.format(word), re.I)
    matches_list = []
    for match in pattern.finditer(NACE):
        matches_list.append(NACE[match.span()[0]:match.span()[-1]].rstrip())
    return matches_list
