## european data on GHG emissions projections
import numpy as np
import pandas as pd
import os

def cls():
    os.system("cls")

## "sniffing" the size of the data
pd.read_csv(r"C:\Users\ludann\Desktop\Python_shit\Datasets" +
    r"\GHG_projections_2018_EEA.csv", usecols = [0, 1]).shape[0]

pd.read_csv(r"C:\Users\ludann\Desktop\Python_shit\Datasets" +
    r"\GHG_projections_2018_EEA.csv", nrows = 10).shape[1]

GHG_EU = pd.read_csv(r"C:\Users\ludann\Desktop\Python_shit\Datasets" +
    r"\GHG_projections_2018_EEA.csv", dtype = str)

def get_unique_vals(data, columns, count = False): # 'columns' mut be list-like
    dict1 = {}
    for column in columns:
        dict1.update({column : data[column].unique()})
    if count == True:
        dict2 = {}
        for key in dict1.keys():
            dict2.update({key : len(dict1[key])})
        return dict2
    else:
        return dict1

GHG_EU.apply(lambda x: x.isna().sum())

## missing data analysis

GHG_missing = GHG_EU.loc[GHG_EU["Reported Value"].isna()].iloc[:, 0:10]
GHG_missing_1 = GHG_EU.loc[GHG_EU["RY calibration"].isna()].iloc[:, 0:10]

(GHG_missing_1.index == GHG_missing.index).sum()
## there are exactly the same missing observations in the
# 'Reported Value' and the 'RY calibration' columns

GHG_missing_2 = GHG_EU.loc[GHG_EU["Final/Gap-filled"].isna()].iloc[:, 0:10]
# check whether
np.sum([i in GHG_missing_1.index for i in GHG_missing_2.index])

GHG_EU["Reported Value"] = (GHG_EU["Reported Value"].
    astype(np.float64))
GHG_EU["RY calibration"] = (GHG_EU["RY calibration"].
    astype(np.float64))
GHG_EU["Final/Gap-filled"] = (GHG_EU["Final/Gap-filled"].
    astype(np.float64))
GHG_EU["Year"] = GHG_EU["Year"].apply(pd.Period)
## doesn't work because there is text in the columns
## locating text in the columns
import re

def search_text(Series, unique_values = True):
    list1 = [bool(re.compile("(?i)[a-z]").search(i))
        for i in Series.dropna()]
    if unique_values == True:
        return Series.dropna()[list1].unique()
    else:
        return Series.dropna()[list1]
## locating text in all columns
for i in GHG_EU:
    print(i)
    search_text(GHG_EU[i])

for i in GHG_EU:
    print(i)
    search_text(GHG_EU[i], False).shape + GHG_EU[i].dropna().shape
## checking column types
for col in GHG_EU:
    set([type(i) for i in GHG_EU[col]])
# setting column types to string
for col in GHG_EU.columns:
    GHG_EU[col] = GHG_EU[col].astype(str)

def no_text_in_numbers(data, columns):
    df_no_text = data.copy()
    for column in columns:
        undesired = search_text(data[column], False).index
        filter = [False if label in undesired else True
            for label in data.index]
        df_no_text[column] = data[column].where(filter)
    return df_no_text

GHG_notext = no_text_in_numbers(GHG_EU,
    ["Reported Value", "RY calibration", "Final/Gap-filled"])

GHG_notext["Reported Value"] = (GHG_notext["Reported Value"].
    astype(np.float64))
GHG_notext["RY calibration"] = (GHG_notext["RY calibration"].
    astype(np.float64))
GHG_notext["Final/Gap-filled"] = (GHG_notext["Final/Gap-filled"].
    astype(np.float64))
##
GHG_notext["Year"] = GHG_notext["Year"].apply(pd.Period)

GHG_EU.drop(["Category_code", "RY calibration", "K",
    "L", "0", "N"], axis = 1, inplace = True)
GHG_notext.drop(["Category_code", "RY calibration", "K",
    "L", "0", "N"], axis = 1, inplace = True)
GHG_EU.to_csv(r"C:\Users\ludann\Desktop\Python_shit\Datasets\emissions_data.csv")
