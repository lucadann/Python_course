## YES / NO

def prova():
    string = 'Dio cane!'
    if input('Sei sicuro di voler saraccare?') == 'Y':
        print(string)
    else:
        print('Segaiolo!')

def are_you_sure(inner_function):
    def wrapper(*args, message = 'Are you sure? ', options = ['Y', 'N'], **kwargs):
        try:
            positive_option = options[0]
            negative_option = options[-1]
        except:
            raise ValueError("'options' argument must be a list of length 2")
        message_to_display = f'{message} [{positive_option}/{negative_option}]'
        response = input(message_to_display)
        while response not in options:
            print('Invalid response, retry!\n')
            response = input(message_to_display)
        if response == positive_option:
            return inner_function(*args, **kwargs)
        elif input(message) == negative_option:
            print('Mission aborted...')
    return wrapper
