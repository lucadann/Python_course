## read range of an excel file as pandas dataframe

from pandas import DataFrame
from openpyxl import load_workbook


def read_xlrange(path = None, sheet_name = None, range_string = None, header = True, index_col=None):
    wb = load_workbook(path, data_only = True)
    if type(sheet_name) == str:
        ws = wb[sheet_name]
    elif type(sheet_name) == int:
        ws = wb.worksheets[sheet_name]
    elif sheet_name == None:
        ws = wb.worksheets[0]
    ws_range = ws[range_string]
    list_range = [[cell.value for cell in row] for row in ws_range[header:]]
    df = DataFrame(list_range, columns = (lambda: [cell.value for cell in ws_range[0]] if header==True else None)())
    if index_col == None:
        return df
    else:
        return df.set_index(index_col)
