################################# Works for "vertical" data sheets
## doesn't work if there are empty values within a table
from openpyxl.worksheet.worksheet import Worksheet
from pandas import DataFrame

def extract_data(worksheet, tolerance = 1):
    data = {}
    rows_list = []
    for row in worksheet.rows:
        row_as_list = []
        for cell in row:
            if cell.value == None:
                continue
            else:
                row_as_list.append(cell.value)
        rows_list.append(row_as_list)
    count = 0
    count_tbl = 1
    rows_for_df = [rows_list[count]]
    for i in range(1, len(rows_list)):
        if len(rows_list[i]) <= tolerance:
            continue
        elif len(rows_list[i]) == len(rows_list[i-1]):
            rows_for_df.append(rows_list[i])
        else:
            data['Table' + str(count_tbl)] = DataFrame(rows_for_df)
            count = i
            count_tbl += 1
            rows_for_df = [rows_list[count]]
    data['Table' + str(count_tbl)] = DataFrame(rows_for_df)
    return data
