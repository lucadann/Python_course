## openpyxl tutorial

from openpyxl import Workbook
import os

wb = Workbook()

## Workbook objects are initialised with one sheet (?)

wb.active #displays active sheet

wb.create_sheet('Sheet1') #inserts worksheet at the end of workbook
wb.create_sheet('Sheet0', 0)
print(type(wb['Sheet1'])) #worksheet object
# note that I can select sheets in a workbook using square brackets
wb.remove_sheet(wb['Sheet']) #removes the default sheet

for sheet, number in zip(wb, range(1, 3)):
    sheet.title = 'Sheet_' + str(number)
# I can loop through sheets

wb.worksheets[0] #I can index by number
# accessing and modifying cells in worksheets
wb['Sheet_1'].cell(row=1, column=1, value='hello') #one-based indexing, like Excel
wb['Sheet_1']['A1'] #returns a cell object
wb['Sheet_1']['A1'].value #returns the value inside the cell
ws3 = wb.create_sheet('Sheet_3') #adds a sheet to the workbook and also stores the worksheet object in a variable
#as always in python (?), altering the variable ws3 also modifies the workbook object

#When a worksheet is created in memory, it contains no cells. They are created when first accessed.

for sheet in wb:
    print(sheet._cells)

## accessing many cells can be done by slicing
ws3['A1':'C3'] #this creates the cells

# I can iterate through rows of a worksheet
for row in wb.worksheets[-1]:
    print row
# assigning values to a range of cells
import random
for i in range(1,4):
    for j in range(1, 4):
        ws3.cell(i, j, random.gauss(0,1))
# iterating through cells
for cell in ws3._cells.values():
    print(cell.value)

# the '_cells' method returns a dictionary, where the keys are tuples showing row and column number for each cell,
# and the values are cell objects

ws3['A1':'C3'] #displays cells by rows (each row is a tuple)
ws3[1] #one-based indexing (returns the first row)

ws3['A'] #returns "A" column as a tuple

ws3['A:B'] #returns specified columns as tuples

ws3['C3'] #returns cell object
ws3['C3'].value #returns value inside the cell

ws3['C3'] = 0 #sets the value of the cell (using the value attribute yields the same result)

ws3._cells[1, 1] #remember that cells is a dictionary with tuples as keys
# WARNING: I can alter the _cells dictionary like any dictionary!!!

for row in ws3.values:
    print(row) #ws3.values is a generator object storing the values of each row
    for value in row:
        print(value)

## iter_rows and iter_cols methods

for row in ws3.iter_rows(range_string = 'A1:C3'):
    print(row)

for col in ws3.iter_cols(min_col = 1, max_col = 3): #no range_string argument
    print(col) #prints columns as tuples

ws3.rows
ws3.columns #generator objects storing rows/columns as tuples
ws3.dimensions #returns string e.g. 'A1:C4'
ws3.max_row
ws3.max_column #return number of rows/columns

## inserting and deleting rows/columns
ws3.insert_rows(3) #inserts a row before the number specified in the argument (works for columns too)
ws3.delete_rows(4)

##loading an existing file

from openpyxl import load_workbook

BIB_Data = load_workbook('../BIB/2019_BIB_Data_request_no_image.xlsx')
BIB_Data.sheetnames
for sheet in BIB_Data:
    print(sheet.dimensions)

Portfolio_migrations = BIB_Data['4.1 Portfolio migrations']

Portfolio_migrations['B'] #returns column as tuple

## looking for values in a column
for keyword in ['NPE stock', 'Cure rate']:
    for cell in Portfolio_migrations['B']:
        if type(cell.value) == str:
           if keyword in cell.value:
                print(cell.value)
                print(Portfolio_migrations['C' + str(cell.row)].value)

## numpy and pandas support
from openpyxl.utils.dataframe import dataframe_to_rows

ws = BIB_Data.worksheets[3]
ws['B10:F21'].values
