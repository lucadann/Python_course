import pandas as pd

test1 = pd.DataFrame({"VAR1" : [1, 2, 3],
    "VAR2" : ["one", "two", "three"]})

if __name__ == "__main__":
    test1.to_csv(r"C:\Users\ludann\Desktop\test1.csv", index = False)
