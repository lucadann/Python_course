# week 3 code
staff_df = pd.DataFrame([{'Name': 'Kelly', 'Role': 'Director of HR'},
                         {'Name': 'Sally', 'Role': 'Course liasion'},
                         {'Name': 'James', 'Role': 'Grader'}])
student_df = pd.DataFrame([{'Name': 'James', 'School': 'Business'},
                           {'Name': 'Mike', 'School': 'Law'},
                           {'Name': 'Sally', 'School': 'Engineering'}])
student_df.set_index("Name", drop = True, inplace = True)
staff_df.set_index("Name", drop = True, inplace = True)

pd.merge(student_df, staff_df, how = "inner",
    left_index = True, right_index = True)

pd.merge(student_df, staff_df, how = "outer",
    right_index = True, left_index = True)

pd.merge(student_df, staff_df, how = "outer", on = "Name")

df = pd.DataFrame({"A" : np.random.normal(0, 1, 6),
    "B" : np.random.binomial(1, 0.7, 6)})
df.index = pd.date_range("20180101", periods = 6, freq = "M")

#eliminating shit
(df.drop(df[df.B == 0].index, axis = 0)
.rename(columns = {"B" : "C"}))


# apply
df2 = pd.DataFrame({"A" : np.random.normal(0, 1, 30),
    "B": np.random.normal(0, 1, 30),
    "C": np.random.normal(0, 1, 30)})

df2.apply(lambda x: np.max(x), axis = 1)


#groupby (basic functionality same as in R)
IFRS9_data = pd.read_csv(r"C:\Users\ludann\Desktop" +
    r"\Python_shit\Datasets\IFRS9_impact.csv", sep = ";")
## get aggregate IFRS9 coverage by bank and by stage
(IFRS9_data.groupby(["BANK", "STAGE"]).
apply(lambda IFRS9_data, x, y: np.divide(np.sum(IFRS9_data[x]),
    np.sum(IFRS9_data[y])),
    "IFRS9_PROV", "GROSS_EXPOSURE").unstack())

(IFRS9_data.groupby(["BANK"]).
agg({"GROSS_EXPOSURE" : np.average, "IFRS9_PROV" : np.sum})
## passes the average to "GROSS_EXPOSURE" and the sum to "IFRS9_PROV"
(IFRS9_data.loc[(IFRS9_data.PRODUCT_TYPE == "Loans") &
    (IFRS9_data.SEGMENT == "Corporate")].
groupby("BANK")["GROSS_EXPOSURE", "IFRS9_PROV"].
agg({"average" : np.average, "sum" : np.sum}))

(IFRS9_data.loc[IFRS9_data.PRODUCT_TYPE == "Loans"].
groupby("QUARTER")["GROSS_EXPOSURE", "IFRS9_PROV"].
agg({"GROSS_EXPOSURE" : np.median, "IFRS9_PROV" : np.average}))
# passes a specified function to each individual column
## constructor functions digression
def fit_params(beta):
    def multip(x):
        return np.inner(x, beta)
    return multip

#              beta          x
fit_params([1, 2, 3])([0.1, 0.1, -0.3])

model1 = lambda x: fit_params([1, 2, 3])(x)

## scales: ratio, interval, ordinal, and nominal (or categorical)
s.astype("category", categories = ["Low", "Medium", "High"],
    ordered = True) ## python 3.7 says this is deprecated wtf??
# dummy variables
pd.get_dummies(IFRS9_data.STAGE)
# creates dummy (True-False) variables from a Series of
# categorical-like data (e.g. IFRS9 stage for bank exposures)

NRG = pd.read_csv(r"energy_data.csv", na_values = ":",
    dtype = {"energy" : np.float64})
NRG.time = pd.to_datetime(NRG.time)
(NRG[np.where(NRG[r"geo\time"].isin(["EU27", "EA19", "EU28"]), False, True)].
where[NRG.time.year]

## pivot tables (practice with IFRS9 data)
(IFRS9_data.where(IFRS9_data.PRODUCT_TYPE == "Loans").
    pivot_table(values = ["GROSS_EXPOSURE", "IFRS9_PROV"],
    index = "BANK", columns = ["STAGE", "QUARTER"],
    aggfunc = np.sum))

## date functionality
pd.Timestamp("20181102")
pd.Period("20181102", "M")
pd.period_range("20181231", "20191231", freq = "M")
pd.date_range("20181231", "20191231", freq = "M")

A = pd.DataFrame({"A" : np.random.binomial(1, 0.4, 300),
    "B" : np.random.normal(loc = 0, scale = 1, size = 300)},
    index = pd.date_range("20181102", periods = 300, freq = "D"))
A.diff() # first-differences all columns (also works with a single series)
A.resample("M").sum() #groups by a specified time interval (in this case, months)
# and applies a function
A["2018-02"] #slices by period (period has to be written in the right format)
A["2018Q4"]
A["2019-02-28":] #works both with dates and periods
A[:"2018-12-31"]
A.asfreq("M", fill = "ffill") # only keeps values at the given frequencies


## using hierarchical indexing as an alternative to groupby
IFRS9_data = IFRS9_data.set_index(["BANK", "QUARTER", "PRODUCT_TYPE",
    "SEGMENT", "BOND_TYPE", "STAGE"])

IFRS9_data.sum(level = ["BANK", "STAGE"])
# not quite as flexible with other functions. Hierarchical indexing is quick
# for looking things up
# groupby can group by index levels, not just columns

(IFRS9_data.loc[["VUB", "PBZ"],:, "Loans", :, :, "Stage 3", :].
groupby(level = ["BANK", "QUARTER"]).apply(lambda x: np.sum(x)/1000).
to_csv(r"C:\Users\ludann\Desktop\test1.csv"))

## reading and writing excel type files
template = pd.ExcelFile("C:/Users/ludann/Documents/ISP FBCRM" +
    "/IFRS9/Impact assessments/Individual banks/30.09.2018" +
    "/PBZ_IFRS9_Impact_Assessment_Template_30092018.xlsx")
IFRS9_template = pd.read_excel(template, sheet_name = 3,
    usecols = "B,C,D,E,F,G,H,I,J,K", skiprows = list(range(5)),
    nrows = 48, names = ["PRODUCT_TYPE", "SEGMENT", "BOND_TYPE",
        "STAGE", "EXP_ONBAL", "EXP_OFFBAL", "TOTAL_EXP",
        "PROV_ONBAL", "PROV_OFFBAL", "TOTAL_PROV"])
IFRS9_template.fillna(method = "ffill", inplace = True)

IFRS9_template["BOND_TYPE"].where(IFRS9_template.PRODUCT_TYPE != "Loans",
    np.nan, inplace = True)

IFRS9_template.to_excel("C:/Users/ludann/Desktop/PBZ_30092018.xlsx")
