### SORTING ###

list1 = [9, 3, 6, 2, 7, 3, 1]

# sorted function
s_list1 = sorted(list1)

print(s_list1)

# sort method of list, does not return a list but sorts in place
list1.sort()

print(list1)

print(sorted(list1, reverse = True))
# descending order

tuple1 = (1, 4, 2, 4, 2, 1, 7, 4, 1)

# the sorted function works on a number of iterables, whereas only lists have the sort method

## RETURNS A LIST
print(sorted(tuple1))

# dictionaries, the sorted function sorts the keys
dict1 = {'a' : 1, 'c' : 2, 'b' : 3}

# always returns a list
print(sorted(dict1))

#sorting by other criteria
li = [-1, 3, -7, 2]
s_li = sorted(li, key = abs)
print(s_li)


def sort_stati(stato):
    stato_comp = stato.replace(' ', '')[:5]
    if stato_comp == 'PERFO':
        return 1
    if stato_comp == 'PASTD':
        return 2
    if stato_comp == 'UTPNO':
        return 3
    if stato_comp == 'UTPDI':
        return 4
    if stato_comp == 'SOFFE':
        return 5

stati = ['UTPNO', 'UTPDI', 'PERFO', 'SOFFE', 'PASTD']

print(sorted(stati, key=sort_stati))

import pandas as pd

ciao = pd.DataFrame({'col1' : ['PERFO', 'UTPNO', 'PASTD', 'SOFFE', 'UTPDI'], 'col2' : [1, 4, 2, 6, 5]})

def key_sort_pandas(data, by, keys):
    df_copy = df.copy()
    by_rev = by.reverse()
    df_copy['sort_key'] = df_copy[''].apply(key)
    return df_copy.sort_values('sort_key')

print(ciao.sort_values('sort_key').drop('sort_key', axis = 1))
