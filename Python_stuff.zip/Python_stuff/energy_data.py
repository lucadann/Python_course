# energy data
import numpy as np
import pandas as pd
import os
def cls():
    os.system("cls")

NRG = pd.read_csv(r"C:\Users\ludann\Desktop\Python_shit\Datasets\nrg_101m.tsv",
    sep = "\t", header = None)#, na_values = ": ")
NRG = (NRG.iloc[:, 0].str.split(pat = ",", expand = True)
    .merge(NRG.iloc[:, 1:], how = "left",
        right_index = True, left_index = True))
NEW_INDEX = list(NRG.iloc[0, 0:4]) + [i[:-1] for i in NRG.iloc[0, 4:]]
NRG.columns = NEW_INDEX
NRG = (NRG.drop(0, axis = 0)
    .reset_index(drop = True))

types = []
for j in NRG.columns:
    class1 = set([type(i) for i in NRG[j]])
    if len(class1) == 1:
        types.append(class1)
    else: print(j, class1)
# all values are strings

NRG = NRG.melt(id_vars = list(NRG.columns)[0:4],
    var_name = "time", value_name = "energy")

 # store flagged values
## regex digression
import re
pattern = re.compile("[0-9]+ [a-z]")
sum([bool(pattern.search(string)) for string in NRG.energy])
#re.search matches the pattern anywhere in the string, while
# re.match matches only at the beginning of the strings
# example
re.match("[a-z]", "2a") #False
re.search("[a-z]", "2a") #True

#create filter
filter = [bool(pattern.search(string)) for string in NRG.energy]
flagged_data = NRG[filter]

NRG.energy = NRG.energy.str.split(pat = " ", expand = True)[0]
NRG.energy.loc[NRG.energy == ":"] = np.nan
NRG.energy = NRG.energy.astype("float", errors = "ignore")

NRG.time = (NRG.time.str.split("M")
    .apply(lambda x: x[0] + x[1]))
NRG.time = pd.to_datetime(NRG.time, format = "%Y%m")

## FCKN ready
