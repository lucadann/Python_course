## subprocess tutorial Corey (<3)

import subprocess

# running external command

# subprocess.run('dir')
## works on linux but not in windows

subprocess.run('dir', shell = True)

# call ???
subprocess.call('dir', shell = True)

## variable

p1 = subprocess.run('dir', shell = True)

print(p1)
# CompletedProcess

print(p1.args)

print(p1.returncode)
# zero means that th proces ran successfully

print(p1.stdout)
# None (because it's sending the standard output to the console)

p2 = subprocess.run('dir', shell = True, capture_output = True)

print(p2.stdout)
## prints as bytes
print(p2.stdout.decode('utf-8'))
## I can also use text = True in the run method

p3 = subprocess.run('dir', shell=True, stdout=subprocess.PIPE, text=True)

print(p3.stdout)

## redirecting the stdout to a file
with open('output.txt', 'w') as f:
    p4 = subprocess.run('dir', stdout = f, shell = True, text = True)

## errors
p5 = subprocess.run('dira', shell = True, stdout = subprocess.PIPE, text = True)

print(p5.stdout)

print(p5.stderr)
## doesn't work in windows (returns None)

print(p5.returncode)
# the return code is non-zero

## throwing a Python exception
# p6 = subprocess.run('dira', shell = True, stdout = subprocess.PIPE, text = True, check = True)

## using output of a subprocess as input to another
p7 = subprocess.run(['type', 'test.txt'], shell = True, stdout=subprocess.PIPE, text = True)

print(p7.stdout)
## doesn't really work with windows because there is no pipe
