## intro to OOP in Python

class Dog:
    def __init__(self, breed, age):
    ## I use the __init__ method to define instance attributes
    # the use of "self" is a convention
        self.breed = breed
        self.age = age

Gigi = Dog("Cocker", 7)

Gigi.breed

## class attributes
class Dog:
    kingdom = "animal"
    def __init__(self, breed, age):
        self.breed = breed
        self.age = age

# class attributes can be obtained by referencing either the class
# or an instance of it
Dog.kingdom
Gigi = Dog("Cocker", 7)
Gigi.kingdom

## instance methods
class Dog:
    kingdom = "animal"
    def __init__(self, name, breed, age):
        self.name = name
        self.breed = breed
        self.age = age
    def human_age(self):
        return Dog(name = self.name,
            breed = self.breed, age = self.age * 7)
    def description(self):
        print("{} is a {}-year old {}".format(self.name, self.age, self.breed))

Gigi = Dog("Gigi", "Cocker", 7)

Gigi.description()
Gigi.human_age().description()

## parent vs child classes
class augmented_list(list):
    def length(self):
         return len(self)

list1 = augmented_list([1, 2, 3, 4])
list1.length()
isinstance(list1, list) #True

############# YOUTUBE TUTORIALS #############
## INSTANCE VARIABLES
# instance variables contain data that is unique to each instance
class Employee:
    pass

emp_1 = Employee()
emp_1.name = "Luca"

class Employee:
    def __init__(self, first, last, pay):
        self.first = first
        self.last = last
        self.pay = pay
        self.email = first[0].lower() + last.replace(" ", "").lower() + "@deloitte.it"
    def fullname(self):
        return "{} {}".format(self.first, self.last)
## methods pass the instance (i.e. "self") to a function
emp_1 = Employee(first = "Francesco", last = "Scartezzini",
    pay = 1700)
# I can call methods from the class name
Employee.fullname(emp_1)
# this is actually what happens in the background all the time

## CLASS VARIABLES (same for each instance)
class Employee:
    def __init__(self, first, last, pay):
        self.first = first
        self.last = last
        self.pay = pay
        self.email = first[0].lower() + last.replace(" ", "").lower() + "@deloitte.it"
    def fullname(self):
        return "{} {}".format(self.first, self.last)
    def apply_raise(self, raise_amt):
        self.pay = int(self.pay * raise_amt)

# suppose the raise factor is always the same across employees
# I could use the same code as above and assign a default value
# to the "raise_amt" variable

# or I could use a class variable
class Employee:
    raise_amt = 1.04
    def __init__(self, first, last, pay):
        self.first = first
        self.last = last
        self.pay = pay
        self.email = first[0].lower() + last.replace(" ", "").lower() + "@deloitte.it"
    def fullname(self):
        return "{} {}".format(self.first, self.last)
    def apply_raise(self):
        self.pay = int(self.pay * self.raise_amt)
# I can call Class Variables both from the class and from an instance
# this way I don't have to enter the raise amount for every
# instance of the class. And I can "update" the raise amount
# by simply assigning any value to it
Employee.raise_amt = 1.05
Employee.raise_amt
# suppose I assign a value from raise_amt from an instance (not from the class)
emp_2 = Employee("Virginia", "Del Tedesco", 1700)
emp_2.__dict__ # prints the namespace of any object
# note that raise_amt does not belong to the namespace
# because it is a class attribute, not an instance attribute
emp_2.raise_amt = 1.06
# this creates the "raise_amt" attribute within emp_2's namespace
## in this case it would be better to call the class variable "raise_amt"
# using "self", as this enables us to update the raise amount for each employee
# and use the correct raise amount in the "apply_raise" method

# here's an example of why I would want to call a class variable
# from a class instead of from an instance
class Employee:
    num_of_emps = 0
    raise_amt = 1.04
    def __init__(self, first, last, pay):
        self.first = first
        self.last = last
        self.pay = pay
        self.email = first[0].lower() + last.replace(" ", "").lower() + "@deloitte.it"
        Employee.num_of_emps += 1
    def fullname(self):
        return "{} {}".format(self.first, self.last)
    def apply_raise(self):
        self.pay = int(self.pay * self.raise_amt)

## regular methods, class methods and static methods

# regular methods automatically take the instance as the first argument

# a class method automatically takes the class as the first argument
class Employee:
    num_of_emps = 0
    raise_amt = 1.04
    def __init__(self, first, last, pay):
        self.first = first
        self.last = last
        self.pay = pay
        self.email = first[0].lower() + last.replace(" ", "").lower() + "@deloitte.it"
        Employee.num_of_emps += 1
    def fullname(self):
        return "{} {}".format(self.first, self.last)
    def apply_raise(self):
        self.pay = int(self.pay * self.raise_amt)
    @classmethod # python decorator
    def set_raise(cls, amount):
        cls.raise_amt = amount
## I could run class methods from an instance but it's not very useful

## using class methods as alternative constructors
class Employee:
    num_of_emps = 0
    raise_amt = 1.04
    def __init__(self, first, last, pay):
        self.first = first
        self.last = last
        self.pay = pay
        self.email = first[0].lower() + last.replace(" ", "").lower() + "@deloitte.it"
        Employee.num_of_emps += 1
    def fullname(self):
        return "{} {}".format(self.first, self.last)
    def apply_raise(self):
        self.pay = int(self.pay * self.raise_amt)
    @classmethod # python decorator
    def set_raise(cls, amount):
        cls.raise_amt = amount
    @classmethod
    def from_str(cls, emp_str, sep):
        first, last, pay = emp_str.split(sep)
        return cls(first, last, pay)

Employee.from_str("Francesco-Scartezzini-1700", sep = "-").email

## static methods don't pass anything automatically
# They are just regular function that have some logical connection
# to the class

# static methods reference neither the instance nor the class
class Employee:
    num_of_emps = 0
    raise_amt = 1.04
    def __init__(self, first, last, pay):
        self.first = first
        self.last = last
        self.pay = pay
        self.email = first[0].lower() + last.replace(" ", "").lower() + "@deloitte.it"
        Employee.num_of_emps += 1
    def fullname(self):
        return "{} {}".format(self.first, self.last)
    def apply_raise(self):
        self.pay = int(self.pay * self.raise_amt)
    @classmethod # python decorator
    def set_raise(cls, amount):
        cls.raise_amt = amount
    @classmethod
    def from_str(cls, emp_str, sep):
        first, last, pay = emp_str.split(sep)
        return cls(first, last, pay)
    @staticmethod
    def is_workday(day):
        if day.weekday() in [5, 6]:
            return False
        else: return True

import datetime as dt

## class inheritance
class Developer(Employee):
    pass
# this inherits all of the functionality from the Employee class
Developer.__dict__
# note that all the Employee attributes are not included in Developer's namespace
class Developer(Employee):
    raise_amt = 1.10
# making changes to subclasses does not affect the parent class
class Developer(Employee):
    raise_amt = 1.10
    def __init__(self, first, last, pay, prog_lang):
        super().__init__(first, last, pay) # lets the parent class handle its own argument
# alternatively Employee.__init__(self, first, last, pay)
        self.prog_lang = prog_lang

dev_1 = Developer("Luca", "Dann", 1500, prog_lang = "Python")
emp_1 = Employee("Chiara", "Sansotta", 2500)

class Manager(Employee):
    def __init__(self, first, last, pay, employees = None):
        super().__init__(first, last, pay)
        if employees == None:
            self.employees = []
        else:
            self.employees = employees
    def add_emps(self, emps):
        self.employees.extend(emps)
    def remove_emps(self, emps):
        for emp in emps:
            self.employees.remove(emp)
    def print_emps(self):
        for emp in self.employees:
            print("-->", emp.fullname())
## I could use positional arguments but it can make things messier
man_1 = Manager("Vincenzo", "Cosenza", 4000, [dev_1, emp_1])

man_1.add_emps(Employee("Virginia", "Del Tedesco", 1700),
    Employee("Francesca", "Conti", 2000))
# isinstance and issubclass
isinstance(man_1, Manager)
isinstance(man_1, Employee)

issubclass(Manager, Employee)

## Special/magic methods
emp_1 = Employee("Luca", "Dann", 1400)
emp_2 = Employee("Virginia", "Del Tedesco", 2000)

repr(emp_1)
str(emp_1)

## the __repr__ and __str__ methods allow us to obtain something more user friendly
# when printing out an Employee object


## the __add__method
emp_1 + emp_2

## the @property decorator allows me to access a method like an attribute (without parentheses)
emp_1.first = "Pedal"
emp_1.email
## setter decorator
emp_1.fullname = "asfasf" ## doesn't work
