## Beautiful Soup and the lxml parser

# we also need the requests library

from bs4 import BeautifulSoup
import requests

## opening an html file (saved on a physical directory)

# with open('HTML/view-source_https___docs.python.org_3_library_sys.html') as html:
#     soup = BeautifulSoup(html, 'lxml')
#
# print(soup.prettify())

## opening the source code from an actual F'ing website
# print('AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA')
#
# ## getting source code
# source = requests.get('https://www.fantacalcio.it/').text
#
# soup2 = BeautifulSoup(source, 'lxml')
#
# # print(soup2.prettify())
#
# article = soup2.find('article')
#
# print(article.prettify())
#
# headline = soup2.find('headline')
#
# print(headline)
# ## nothing
#
# summary=article.find('div', class_='entry-content')
#
# print(summary)


## requests stuff

source_fc = requests.get('https://www.fantacalcio.it/statistiche-serie-a/2019-20/fantacalcio/medie')

print(source_fc.links)
