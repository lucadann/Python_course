import csv
from pykml import parser
#
def parse_kml(path):
    with open(path) as f:
        tree = parser.parse(f)
    root = tree.getroot()
    for folder in root.Document.Folder:
        for placemark in folder.Placemark:
            coord_list = placemark.Point.coordinates.text.strip().split(',')
            row = [folder.name.text, placemark.name.text] + coord_list
            yield row

def kml_to_csv(path, out, header_row):
    rows = parse_kml(path)
    with open(out, 'w', newline='') as csvfile:
        writer = csv.writer(csvfile)
        writer.writerow(header_row)
        for row in rows:
            writer.writerow(row)

if __name__ == '__main__':
    kml_to_csv('parse_xml/Parchi Comune Copparo.kml', 'parse_xml/out.csv', ['Parco', 'Nome Scientifico', 'Latitudine', 'Longitudine', 'Altitudine'])
